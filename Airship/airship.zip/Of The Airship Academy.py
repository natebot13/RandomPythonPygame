import pygame
import random
import math

class Cloud():
	def __init__(self, x, y):
		self.rotation = random.randint(-10,10)
		self.xvel = random.random()*random.randint(-1,1)
		self.yvel = random.random()*random.randint(-1,1)
		self.surf = pygame.image.load("cloud.png").convert_alpha()
		self.x = x - self.surf.get_width()/2
		self.y = y - self.surf.get_height()/2
		self.surf.set_alpha(random.randint(0,255))
		self.decay = random.randint(0,255)

class CloudGroup():
	def __init__(self, x, y, puffs=25, size=64):
		self.x = x
		self.y = y
		self.size = size
		self.clouds = []
		for i in range(puffs):
			self.clouds.append(Cloud(self.x+random.randint(-self.size,self.size), self.y+random.randint(-self.size,self.size)))
			#print "cloud # " + str(i)
	
	def drawCloud(self, screen):
		for i in range(len(self.clouds)):
			#print self.clouds[i].surf.get_alpha()
			screen.blit(self.clouds[i].surf, (self.clouds[i].x, self.clouds[i].y))
			self.clouds[i].x = self.clouds[i].x + self.clouds[i].xvel
			self.clouds[i].y = self.clouds[i].y + self.clouds[i].yvel
			#self.clouds[i].surf = pygame.transform.rotate(self.clouds[i].surf, self.clouds[i].rotation)
			self.clouds[i].surf.set_alpha(self.clouds[i].surf.get_alpha()-5)
			if self.clouds[i].surf.get_alpha() <= 0:
				#print "making new cloud..."
				del self.clouds[i]
				self.clouds.insert(i, Cloud(self.x+random.randint(-self.size,self.size), self.y+random.randint(-self.size,self.size)))
				
	def scroll(self, dx=0, dy=0):
		self.x = self.x + dx
		self.y = self.y + dy
		for i in range(len(self.clouds)):
			self.clouds[i].x = self.clouds[i].x + dx
			self.clouds[i].y = self.clouds[i].y + dy

class Ship():
	def __init__(self, x, y):
		self.surf = pygame.image.load("airship.png").convert_alpha()
		self.x = x - self.surf.get_width()/2
		self.y = y - self.surf.get_height()/2
		self.offset = 0.0
	
	def drawShip(self, screen):
		screen.blit(self.surf, (self.x, self.y+(16*math.sin(self.offset))))
		self.offset = self.offset + .1
		#self.surf = pygame.transform.rotate(self.surf, 2)
		

if __name__ == "__main__":
	
	pygame.mixer.init()
	
	WIDTH = 512
	HEIGHT = 512
	SIZE = (WIDTH,HEIGHT)
	FPS = 10
	fpsClock = pygame.time.Clock()
		
	SCREEN = pygame.display.set_mode(SIZE)
	pygame.display.set_caption('Of The Airship Academy')
	manycloudgroups = []
	for i in range(7):
		manycloudgroups.append(CloudGroup(random.randint(-200,WIDTH+200), random.randint(-200,HEIGHT+200)))
	
	ship = Ship(WIDTH/2, HEIGHT/2)
	
	pygame.mixer.music.load("Of The Airship Academy.mp3")
	pygame.mixer.music.play(-1, 1)
	
	blackness = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA).convert()
	trans = 255.0
	
	while True:
		
		for event in pygame.event.get():
			pass
		
		
		SCREEN.fill((221,136,0))
		
		for i in range(len(manycloudgroups)):
			manycloudgroups[i].drawCloud(SCREEN)
			manycloudgroups[i].scroll(-4)
			if manycloudgroups[i].x < -200:
				del manycloudgroups[i]
				manycloudgroups.insert(i, CloudGroup(WIDTH + 100 + random.randint(0,100), random.randint(0,HEIGHT)))
		
		ship.drawShip(SCREEN)
		
		if trans > 0:
			SCREEN.blit(blackness, (0,0))
			trans-=.5
			blackness.set_alpha(trans)
		
		pygame.display.update()
		fpsClock.tick(FPS)
